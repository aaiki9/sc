from kyt import *

@bot.on(events.CallbackQuery(data=b'domain'))
async def perpanjang(event):
    async def perpanjang_(event):
        chat = event.chat_id  # Ambil ID obrolan dari objek event
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True))
            user = (await user).raw_text
        async with bot.conversation(chat) as pw:
            await event.respond("**Input IP VPS:**")
            pw = pw.wait_event(events.NewMessage(incoming=True))
            pw = (await pw).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih Domain Nya**", buttons=[
                [Button.inline(" x-vpn.tech ", "1"),
                 Button.inline(" guidolive.me ", "2")],
                [Button.inline(" freakly.pro ", "3"),
                Button.inline(" one1ik.pro ", "4")],
                [Button.inline(" frishly.pro ", "5"),
                Button.inline(" kylia1704.biz.id ", "6")],
                [Button.inline(" tallyberry.my.id ", "7"),
                 Button.inline(" ahmadarifky27.my.id ", "8")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | domain'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"Error: {e}")
        else:
            msg = f"""```{a}```
**» 🤖@KyyLearning27**"""
            await event.respond(msg)

    # Tidak perlu pengecekan validitas, langsung jalankan fungsi
    await perpanjang_(event)
