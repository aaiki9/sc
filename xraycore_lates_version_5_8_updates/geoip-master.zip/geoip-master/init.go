package main

import (
	_ "github.com/Loyalsoldier/geoip/plugin/maxmind"
	_ "github.com/Loyalsoldier/geoip/plugin/plaintext"
	_ "github.com/Loyalsoldier/geoip/plugin/special"
	_ "github.com/Loyalsoldier/geoip/plugin/v2ray"
)
